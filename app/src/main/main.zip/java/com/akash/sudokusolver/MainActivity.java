package com.akash.sudokusolver;

import android.content.Intent;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import org.opencv.android.OpenCVLoader;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends AppCompatActivity {

    private String DATA_PATH;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        DATA_PATH = Environment.getExternalStorageDirectory().toString() + "/SudokuSolver/tessdata/";
        Log.d("path", DATA_PATH);
        AssetManager am = getAssets();
        File dir = new File(DATA_PATH);
        if (!dir.exists()) {
            if (!dir.mkdirs()) {
                Log.d("DIR", "ERROR: Creation of directory " + DATA_PATH + " on sdcard failed");
                return;
            } else {
                Log.d("EDIR", "Created directory " + DATA_PATH + " on sdcard");
            }

        }
        File data = new File(DATA_PATH + "eng.traineddata");
        if (!data.exists()) {
            try {
                InputStream is = am.open("tessdata/eng.traineddata");
                OutputStream out = new FileOutputStream(DATA_PATH + "eng.traineddata");
                byte[] buf = new byte[1024];
                int len;
                while ((len = is.read(buf)) > 0) {
                    out.write(buf, 0, len);
                }
                is.close();
                out.close();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
                Log.d("errorFNF", e.toString());
            } catch (IOException e) {
                e.printStackTrace();
                Log.d("errorIO", e.toString());
            }
        }
        if (OpenCVLoader.initDebug()) {
            Log.d("opencv", "loaded");
            SudokuSolve solve = new SudokuSolve();
            try {
                solve.solve(MainActivity.this, Environment.getExternalStorageDirectory().toString() + "/SudokuSolver/sudokuSample.png");
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            //net beans ma border bani dai pela and joi lai output...

            Log.d("opencv", "Not loaded");
        }
        Button button = (Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, CameraOpen.class);
                startActivityForResult(intent, 1313);
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 1313 && resultCode == RESULT_OK) {
            if (OpenCVLoader.initDebug()) {
                Log.d("opencv", "loaded");
                SudokuSolve solve = new SudokuSolve();
                try {
                    solve.solve(MainActivity.this, Environment.getExternalStorageDirectory().toString() + "/SudokuSolver/sudokuSample.png");
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else {
                //net beans ma border bani dai pela and joi lai output...

                Log.d("opencv", "Not loaded");
            }
        }
    }
}